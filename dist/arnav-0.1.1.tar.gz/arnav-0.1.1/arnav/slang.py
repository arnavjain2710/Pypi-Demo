class slang:
    def slang():
        print("Jasmer chutiya hai!")