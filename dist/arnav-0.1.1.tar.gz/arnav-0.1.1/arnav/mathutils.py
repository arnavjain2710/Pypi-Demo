class mathutils:
    def addition(a,b):
        return a+b