from arnav.slang import slang
from arnav.mathutils import addition