class slang:
    def slang():
        print("Hello friend!")